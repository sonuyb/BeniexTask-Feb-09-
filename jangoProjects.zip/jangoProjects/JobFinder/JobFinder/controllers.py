
# from django.http import HttpResponse

class Controller:
    @staticmethod
    def get_data(request):
        # Process data or perform any necessary actions
        data = "Hello, world!"
        
        # Render a template and pass data to it
        return {data,request}
