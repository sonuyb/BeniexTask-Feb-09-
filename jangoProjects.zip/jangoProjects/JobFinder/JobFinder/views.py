from django.shortcuts import render
from django.views import View
# from django.http import HttpResponse
from .controllers import Controller
# Create your views here.

class IndexView(View):
    def get(self, request):
        return render(request, 'index.html')

class LoginView(View):
    def get(self, request):
        return render(request, 'login.html',{'isLoginForm': True})

class SignUpView(View):
    def get(self, request):
        return render(request, 'registration.html',{'isRegistrationForm': True})