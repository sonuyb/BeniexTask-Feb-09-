from django.shortcuts import render
from django.views import View
from django.http import HttpResponse

# Create your views here.

class CreateView(View):
    def get(self, request):
        return render(request, 'create.html')
    def post(self, request):
        if request.POST:
            print (request.POST)
            return HttpResponse("success")

class ListView(View):
    def get(self, request):
        return render(request, 'list.html')

class EditView(View):
    def get(self, request):
        return render(request, 'edit.html')